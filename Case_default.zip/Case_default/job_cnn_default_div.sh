#!/bin/bash
#
#SBATCH --job-name=cnn_default_div
#SBATCH --output=logs/cnn_%A.out
#SBATCH --error=logs/cnn_%A.err
#
#SBATCH --nodes=1
#SBATCH --time=24:00:00
#SBATCH --nodelist=komputasi06

source ~/New_DE_CNN/bin/activate



srun python cnn_default_div.py s31 valence &
srun python cnn_default_div.py s32 valence &
wait
