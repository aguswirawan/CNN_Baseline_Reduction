#!/bin/bash
#
#SBATCH --job-name=3D_default_fractional
#SBATCH --output=logs/cnn_%A.out
#SBATCH --error=logs/cnn_%A.err
#
#SBATCH --nodes=1
#SBATCH --time=24:00:00
#SBATCH --nodelist=komputasi04

source ~/New_DE_CNN/bin/activate

srun python 3D_default_fractional.py
