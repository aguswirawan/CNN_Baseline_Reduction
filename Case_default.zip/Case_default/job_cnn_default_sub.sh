#!/bin/bash
#
#SBATCH --job-name=cnn_default_sub
#SBATCH --output=logs/cnn_%A.out
#SBATCH --error=logs/cnn_%A.err
#
#SBATCH --nodes=1
#SBATCH --time=24:00:00
#SBATCH --nodelist=komputasi03

source ~/New_DE_CNN/bin/activate


srun python cnn_default_sub.py s01 arousal &
srun python cnn_default_sub.py s02 arousal &
wait

srun python cnn_default_sub.py s03 arousal &
srun python cnn_default_sub.py s04 arousal &
srun python cnn_default_sub.py s05 arousal &
wait


srun python cnn_default_sub.py s06 arousal &
srun python cnn_default_sub.py s07 arousal &
wait

srun python cnn_default_sub.py s08 arousal &
srun python cnn_default_sub.py s09 arousal &
srun python cnn_default_sub.py s10 arousal &
wait


srun python cnn_default_sub.py s11 arousal &
srun python cnn_default_sub.py s12 arousal &
wait

srun python cnn_default_sub.py s13 arousal &
srun python cnn_default_sub.py s14 arousal &
srun python cnn_default_sub.py s15 arousal &
wait


srun python cnn_default_sub.py s16 arousal &
srun python cnn_default_sub.py s17 arousal &
wait

srun python cnn_default_sub.py s18 arousal &
srun python cnn_default_sub.py s19 arousal &
srun python cnn_default_sub.py s20 arousal &
wait


srun python cnn_default_sub.py s21 arousal &
srun python cnn_default_sub.py s22 arousal &
wait

srun python cnn_default_sub.py s23 arousal &
srun python cnn_default_sub.py s24 arousal &
srun python cnn_default_sub.py s25 arousal &
wait


srun python cnn_default_sub.py s26 arousal &
srun python cnn_default_sub.py s27 arousal &
wait

srun python cnn_default_sub.py s28 arousal &
srun python cnn_default_sub.py s29 arousal &
srun python cnn_default_sub.py s30 arousal &
wait

srun python cnn_default_sub.py s31 arousal &
srun python cnn_default_sub.py s32 arousal &
wait

srun python cnn_default_sub.py s01 valence &
srun python cnn_default_sub.py s02 valence &
srun python cnn_default_sub.py s03 valence &
wait

srun python cnn_default_sub.py s04 valence &
srun python cnn_default_sub.py s05 valence &
wait


srun python cnn_default_sub.py s06 valence &
srun python cnn_default_sub.py s07 valence &
srun python cnn_default_sub.py s08 valence &
wait

srun python cnn_default_sub.py s09 valence &
srun python cnn_default_sub.py s10 valence &
wait


srun python cnn_default_sub.py s11 valence &
srun python cnn_default_sub.py s12 valence &
srun python cnn_default_sub.py s13 valence &
wait

srun python cnn_default_sub.py s14 valence &
srun python cnn_default_sub.py s15 valence &
wait


srun python cnn_default_sub.py s16 valence &
srun python cnn_default_sub.py s17 valence &
srun python cnn_default_sub.py s18 valence &
wait

srun python cnn_default_sub.py s19 valence &
srun python cnn_default_sub.py s20 valence &
wait


srun python cnn_default_sub.py s21 valence &
srun python cnn_default_sub.py s22 valence &
srun python cnn_default_sub.py s23 valence &
wait

srun python cnn_default_sub.py s24 valence &
srun python cnn_default_sub.py s25 valence &
wait


srun python cnn_default_sub.py s26 valence &
srun python cnn_default_sub.py s27 valence &
srun python cnn_default_sub.py s28 valence &
wait

srun python cnn_default_sub.py s29 valence &
srun python cnn_default_sub.py s30 valence &
wait

srun python cnn_default_sub.py s31 valence &
srun python cnn_default_sub.py s32 valence &
wait
